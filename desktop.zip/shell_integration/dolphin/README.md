<!--
  - SPDX-FileCopyrightText: 2014 ownCloud GmbH
  - SPDX-License-Identifier: GPL-2.0-or-later
-->
- Recompile and install recent enough version of dolphin and kio (git from oct 2015)

- Build and install the plugin

- Make sure to set XDG_DATA_DIRS=$PREFIX/share, QT_PLUGIN_PATH=$PREFIX/lib64/plugins/

- After installing, run
    kdeinit5 --noincremental

- restart dolphin (make sure to kill all instances)

