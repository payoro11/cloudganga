This is the src directory of the  QtLockedFile
solution integrated over from Qt's Qt Creator.

It is required by the QtSingleApplication solution.

