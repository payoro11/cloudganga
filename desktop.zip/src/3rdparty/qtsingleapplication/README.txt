This is the src directory of the QtSingleApplication solution
integrated over from Qt's Qt Creator project.

It additionally requires the QtLockedFile solution.

