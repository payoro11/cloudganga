\defgroup cmd The command line client

<!--
  - SPDX-FileCopyrightText: 2015 ownCloud GmbH
  - SPDX-License-Identifier: GPL-2.0-or-later
-->

The command line client
=======================
