<!--
  - SPDX-FileCopyrightText: 2015 ownCloud GmbH
  - SPDX-License-Identifier: GPL-2.0-or-later
-->
The GUI Client
==============

\defgroup gui The GUI client

