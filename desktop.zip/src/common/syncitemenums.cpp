/*
 * SPDX-FileCopyrightText: 2020 ownCloud GmbH
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#include "syncitemenums.h"
#include "moc_syncitemenums.cpp"
