<!--
  - SPDX-FileCopyrightText: 2017 ownCloud GmbH
  - SPDX-License-Identifier: LGPL-2.1-or-later
--> 
This folder contains code covered by the CLA being licensed as LGPL.
This allows it to be linked together with the rest of the LGPL code in csync.
